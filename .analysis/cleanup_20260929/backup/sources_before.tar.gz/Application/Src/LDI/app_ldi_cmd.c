#include "app_ldi_cmd.h"

#include <time.h>

#include "crc_utils.h"
#include "pl_crc.h"
#include "app_ldi_cfg.h"
#include "app_board_net_cfg.h"
#include "pl_net.h"
#include "pl_rtc.h"
#include "pl_sys.h"
#include "app_vms_ctrl.h"
#include "app_ldi_device.h"
#include "app_udp.h"
#include "app_tcp_server.h"

/** 请求帧序号（由 ldi_probe_frame 保存，用于响应帧回显） */

// ============================================================================
// 各命令 DATA 域完整帧结构定义
// ============================================================================
//
// 以下 struct 定义的是 ldi_frame_t.data_crc[] 中 DATA 段的完整布局,
// 均以 ldi_req_head_t 开头 (20字节通用头部), 后续字段视命令而定.
//
// 注: 这些 struct 仅用于描述帧结构, 实际解析时通过指针偏移遍历.

/**
 * 网络配置信息 — set_ip / rep_ip_rsp 共用
 *
 * 网络参数块共 65 字节，不含 20 字节通用 head 和 1 字节 ErrorCode。
 * 请求 0AH: DATA offset 20 起；响应 D1H: DATA offset 21 起。
 */
typedef struct [[gnu::packed]] {
    uint8_t host_ip[4];     // 上位机 IP1 (外设控制服务)
    uint8_t host_port[2];   // 上位机端口1
    uint8_t reserve1[39];   // 预留段 (含 ServerIP2~3, MQTT 全套参数)
    uint8_t ntp_ip[4];      // 对时服务器 IP
    uint8_t device_ip[4];   // 设备自身 IP
    uint8_t device_port[2]; // 设备端口号
    uint8_t gateway[4];     // 网关地址
    uint8_t netmask[4];     // 子网掩码
    uint8_t reserve2[2];    // 保留字节
} ldi_network_info_t;

/* 4.1.1 request network block: DATA offset 20, length 65 bytes. */
static_assert(sizeof(ldi_network_info_t) == 65, "LDI network block must be 65 bytes");
static_assert(offsetof(ldi_network_info_t, ntp_ip) == 45, "NtpIP offset must be 45");
static_assert(offsetof(ldi_network_info_t, device_ip) == 49, "DeviceIP offset must be 49");
static_assert(offsetof(ldi_network_info_t, device_port) == 53, "DevicePort offset must be 53");
static_assert(offsetof(ldi_network_info_t, gateway) == 55, "Gateway offset must be 55");
static_assert(offsetof(ldi_network_info_t, netmask) == 59, "Netmask offset must be 59");
static_assert(offsetof(ldi_network_info_t, reserve2) == 63, "D1H reserved offset must be 63");

/**
 * 设备 IP 信息设置 (0AH) DATA 域 — 共 85 字节 (含 head)
 * head(20B) + network_info(67B)
 */
typedef struct [[gnu::packed]] {
    ldi_req_head_t head;
    ldi_network_info_t net;
} cmd_set_ip_t;

/**
 * 设备参数配置 (0BH) DATA 域
 *
 * 对应协议第4.2.1节. 上位机→设备.
 * 帧布局: head(20B) | device_num(1B) | module[0] | ... | module[N-1]
 *
 * module 结构视 device_type 而定, 公共头见 ldi_module_head_t,
 * 各设备 payload 定义见 ldi_cfg_barrier_t / ldi_cfg_display_t 等
 */
typedef struct [[gnu::packed]] {
    ldi_req_head_t head; // 通用头部, cmd_type=0BH
    uint8_t device_num;  // 功能模块数量 N
    uint8_t module[];    // module 序列 (柔性数组), 遍历时按 device_type 查表推进
} cmd_set_config_t;

/**
 * 设备重启 (0DH) DATA 域
 *
 * 对应协议第4.3.1节. 上位机→设备.
 * 帧布局: head(20B) | device_num(1B) | module[0] | ... | module[N-1]
 *
 * 每个 module = device_type(1B) + device_index(1B) + vendor[10],
 * 所有设备统一使用 ldi_reboot_payload_t
 */
typedef struct [[gnu::packed]] {
    ldi_req_head_t head; // 通用头部, cmd_type=0DH
    uint8_t device_num;  // 功能模块数量 N
    uint8_t module[];    // module 序列 (柔性数组)
} cmd_reboot_t;

/**
 * 设备 IP 信息采集 (1DH) DATA 域
 *
 * 对应协议第4.4.1节. 上位机→设备, 查询设备当前网络配置.
 * 帧布局: 仅含通用头部 (无额外字段)
 */
typedef struct [[gnu::packed]] {
    ldi_req_head_t head; // 通用头部, cmd_type=1DH
} cmd_rep_ip_t;

/**
 * 设备参数采集 (1EH) DATA 域
 *
 * 对应协议第4.5.1节. 上位机→设备, 查询设备当前业务参数.
 * 帧布局: 仅含通用头部 (无额外字段)
 */
typedef struct [[gnu::packed]] {
    ldi_req_head_t head; // 通用头部, cmd_type=1EH
} cmd_rep_config_t;

// ============================================================================
// 响应帧 payload 结构体
// ============================================================================

/** 状态响应（通用 ACK + 可附带 payload）
 *
 *  set_ip_rsp/A0H, init_rsp/A1H 等单设备 ACK 直接使用。
 *  rep_ip/D1H 等查询响应将 ldi_network_info_t 放入 payload[]。
 *  status: 00H=成功, 01H=失败
 */
typedef struct [[gnu::packed]] {
    ldi_req_head_t head;
    uint8_t status;
    uint8_t payload[]; // 柔性数组，查询响应时携带业务数据
} ldi_status_rsp_t;

/** 多设备操作响应（set_config_rsp=B0H, reboot_rsp=D0H） */
typedef struct [[gnu::packed]] {
    ldi_req_head_t head;
    uint8_t device_num;
    struct {
        uint8_t device_type;
        uint8_t device_index;
        uint8_t status;
    } modules[]; // N × 3 字节
} ldi_multi_rsp_t;

/** 初始化响应帧单个 module 信息（A1H: 设备→上位机）

    device_type(1) + device_index(1) + status(1) + software_version(2) +
    firmware_version(2) + protocol_version(2) + custom_init_len(1) = 定长 10 字节
    custom_init[] 为柔性数组，长度由 custom_init_len 指示。 */
typedef struct [[gnu::packed]] {
    ldi_module_head_t head;      // device_type + device_index (2B)
    uint8_t status;              // 功能模块状态: 00H=正常, 01H=异常
    uint8_t software_version[2]; // 软件版本号
    uint8_t firmware_version[2]; // 固件版本号
    uint8_t protocol_version[2]; // 接口协议版本号, 默认 00H
    uint8_t custom_init_len;     // 个性化初始化内容字节长度 S
    uint8_t custom_init[];       // 个性化初始化内容 (S 字节), 当前为空
} ldi_init_rsp_module_t;

static_assert(sizeof(ldi_init_rsp_module_t) == 10, "ldi_init_rsp_module_t fixed part must be 10 bytes");

/** 初始化响应帧 DATA 域（A1H: head + device_num + N×变长module） */
typedef struct [[gnu::packed]] {
    ldi_req_head_t head;
    uint8_t device_num;
    uint8_t modules[]; // N × 变长模块
} ldi_init_rsp_t;

/** 参数采集响应帧 DATA 域（E1H: head + device_num + N×变长module）

    module 结构与 0BH 设置时一致，各设备 vendor 长度不同，
    详见 ldi_cfg_module_size()。构造时需动态拼接，不使用固定 struct 做 modules[] 元素。 */
typedef struct [[gnu::packed]] {
    ldi_req_head_t head;
    uint8_t device_num;
    uint8_t modules[]; // 变长 module 序列，逐设备用 ldi_cfg_module_size() 推进
} ldi_rep_config_rsp_t;

/** 控制/查询响应 payload（ctrl_rsp=B1H，每个 module 4 字节） */
typedef struct [[gnu::packed]] {
    uint8_t device_type;
    uint8_t device_index;
    uint8_t device_func_type;
    uint8_t status; // 00H=成功, 01H=失败
} ldi_ctrl_rsp_payload_t;

/** 控制/查询响应帧 DATA 域（B1H，24 字节 ctrl_head + N×4 字节 modules） */
typedef struct [[gnu::packed]] {
    ldi_ctrl_head_t head; // 24 字节，8 字节时间戳
    uint8_t device_num;
    ldi_ctrl_rsp_payload_t modules[]; // N × 4 字节
} ldi_ctrl_rsp_t;

/** 设备搜索应答帧 DATA 域（0x12，UDP 广播，16 字节定长） */
typedef struct [[gnu::packed]] {
    uint8_t cmd_type;   // 0x12 = 设备搜索应答
    uint8_t ip[4];      // 设备自身 IP, 大端
    uint8_t port[2];    // 设备端口号, 大端
    uint8_t gateway[4]; // 网关地址, 大端
    uint8_t mask[4];    // 子网掩码, 大端
    uint8_t err_code;   // 00H=成功, 01H=失败
} ldi_search_rsp_t;

// ============================================================================
// module 尺寸查表
// ============================================================================
//
// 复合指令中每个 module 长度 = ldi_module_head_t(2B) + 设备特定 payload
// 以下函数按 device_type 返回 module 总字节数, 用于遍历时推进指针.
//
// 注意: 变长设备 (如 LPR 含图片上传地址) 的 module 长度需从帧内字段
//       推算, 查表返回 0 表示调用方需自行计算.

/**
 * 获取 0BH 参数配置命令中指定设备类型的 module 总长度
 *
 * @param type  device_type (E4H~EBH)
 * @return      module 总字节数 (含 module_head 的 2 字节),
 *              未知类型返回 0
 */
static uint8_t ldi_cfg_module_size(ldi_device_t type)
{
    switch (type) {
        case LDI_DEV_TYPE_BARRIER: // E4H: head(2) + filter_time(1) + vendor(10) = 13
            return sizeof(ldi_module_head_t) + sizeof(ldi_cfg_barrier_t);
        case LDI_DEV_TYPE_DISPLAY: // E6H: head(2) + font_line(1) + vendor(10) = 13
            return sizeof(ldi_module_head_t) + sizeof(ldi_cfg_display_t);
        case LDI_DEV_TYPE_LANE_SIGNAL: // E7H: head(2) + vendor(2) = 4
            [[fallthrough]];
        case LDI_DEV_TYPE_ALARM: // E8H: 同上, 共 4 字节
            [[fallthrough]];
        case LDI_DEV_TYPE_CANOPY_LIGHT: // EAH: 同上, 共 4 字节
            [[fallthrough]];
        case LDI_DEV_TYPE_FOG_LIGHT: // EBH: 同上, 共 4 字节
            return sizeof(ldi_module_head_t) + sizeof(ldi_cfg_signal_t);
        case LDI_DEV_TYPE_VMS: // E9H: head(2) + vendor(10) = 12
            return sizeof(ldi_module_head_t) + sizeof(ldi_cfg_vms_t);
        case LDI_DEV_TYPE_VOICE:
            return sizeof(ldi_module_head_t) + sizeof(ldi_cfg_voice_t);
        default:
            return 0; // 未知设备类型, 调用方应视为错误
    }
}

/**
 * @brief 获取 1BH 控制/查询命令中指定设备类型的 payload 定长部分长度
 *
 * @note 返回值已扣除 DeviceFuncType(1B), 即纯功能参数的长度.
 *       多功能设备 (Display/VMS) 根据 func_type 返回对应长度;
 *       text[] 等变长字段不计入, 由调用方根据 mod_len 推算.
 *
 * @param type      设备类型
 * @param func_type 功能编号 (01H=显示控制, 02H=清屏 等)
 * @return          payload 定长部分字节数 (不含 DeviceFuncType), 未知返回 0
 */
[[maybe_unused]] static uint8_t ldi_ctrl_payload_size(ldi_device_t type, uint8_t func_type)
{
    switch (type) {
        case LDI_DEV_TYPE_BARRIER: // E4H: status(1) = 1B
            return sizeof(ldi_ctrl_barrier_t) - 1;
        case LDI_DEV_TYPE_DISPLAY:                                        // E6H: 01H=4B(union)+text[], 02H=1B(clear_type)
            if (func_type == 0x01) return sizeof(ldi_ctrl_display_t) - 1; // 4
            if (func_type == 0x02) return 1;
            return 0;
        case LDI_DEV_TYPE_LANE_SIGNAL: // E7H: color(1) = 1B
            return sizeof(ldi_ctrl_signal_t) - 1;
        case LDI_DEV_TYPE_ALARM: // E8H: status(1)+work_mode(1)+keep_time(1) = 3B
            return sizeof(ldi_ctrl_alarm_t) - 1;
        case LDI_DEV_TYPE_VMS:                                        // E9H: 01H=5B(union)+text[], 02H=1B(clear_type)
            if (func_type == 0x01) return sizeof(ldi_ctrl_vms_t) - 1; // 5
            if (func_type == 0x02) return 1;
            return 0;
        case LDI_DEV_TYPE_CANOPY_LIGHT: // EAH: color(1) = 1B
            return sizeof(ldi_ctrl_canopy_light_t) - 1;
        case LDI_DEV_TYPE_FOG_LIGHT: // EBH: status(1)+work_mode(1) = 2B
            return sizeof(ldi_ctrl_fog_light_t) - 1;
        case LDI_DEV_TYPE_VOICE: // F4H: type(1)+length(2) = 3B, data[] 由 length 推算
            return sizeof(ldi_ctrl_voice_t) - 1;
        default:
            return 0;
    }
}

// ============================================================================
// 编译期尺寸校验
// ============================================================================
// 确保 struct 布局与协议定义逐字节一致, 避免因 padding/对齐导致帧解析错位
static_assert(sizeof(ldi_module_head_t) == 2, "ldi_module_head_t must be 2 byte");

static_assert(sizeof(ldi_cfg_barrier_t) == 11, "ldi_cfg_barrier_t must be 11 byte");
static_assert(sizeof(ldi_cfg_display_t) == 11, "ldi_cfg_display_t must be 11 byte");
static_assert(sizeof(ldi_cfg_signal_t) == 2, "ldi_cfg_signal_t must be 3 byte");
static_assert(sizeof(ldi_cfg_vms_t) == 10, "ldi_cfg_vms_t must be 11 byte");

static_assert(sizeof(ldi_reboot_payload_t) == 10, "ldi_reboot_payload_t must be 10 byte");

static_assert(sizeof(ldi_ctrl_barrier_t) == 2, "ldi_ctrl_barrier_t must be 2 byte");
static_assert(sizeof(ldi_ctrl_display_t) == 5, "ldi_ctrl_display_t fixed part must be 5 byte");
static_assert(sizeof(ldi_ctrl_signal_t) == 2, "ldi_ctrl_signal_t must be 2 byte");
static_assert(sizeof(ldi_ctrl_alarm_t) == 4, "ldi_ctrl_alarm_t must be 4 byte");
static_assert(sizeof(ldi_ctrl_vms_t) == 6, "ldi_ctrl_vms_t fixed part must be 6 byte");
static_assert(sizeof(ldi_ctrl_canopy_light_t) == 2, "ldi_ctrl_canopy_light_t must be 2 byte");
static_assert(sizeof(ldi_ctrl_fog_light_t) == 3, "ldi_ctrl_fog_light_t must be 3 byte");
static_assert(sizeof(ldi_ctrl_voice_t) == 4, "ldi_ctrl_voice_t fixed part must be 4 byte");

// ============================================================================
// LDI 响应帧构造器
// ============================================================================
//
// ldi_send_response 处理 STX/VER/SEQ/LEN/CRC 这些共有帧结构，
// 各命令只需准备自己的 DATA 域 payload 即可。
//
// seq 规则：
//   请求-响应 → 回显请求帧的 seq（探头函数已保存到 g_ldi.rsp_seq）
//   主动上报 → 使用 g_ldi.rpt_seq，发送后自增

/** 设备主动上报帧序号计数器 */

/** 获取下一主动上报帧序号（0x10, 0x20, ... ，高半字节递增，协议 §3.2） */
static uint8_t ldi_next_rpt_seq(void)
{
    uint8_t seq = ++g_ldi.rpt_seq;
    return (seq << 4) & 0xF0; /* 0x10, 0x20, ... 0xF0 */
}

/**
 * @brief 从 DATA 域指针反推该帧的 DATA 域长度
 *
 * 命令处理函数只收到 data_crc 首字节指针；ldi_frame_t 的 LEN 字段（4 字节大端）
 * 紧邻 data_crc 之前，且 probe 已保证完整帧落在队列缓冲内，故可安全反推，
 * 供各命令做 data_len 下限 / 剩余帧长校验。
 */
static uint32_t _ldi_data_len(const void *data)
{
    const uint8_t *p = (const uint8_t *)data;
    return ((uint32_t)p[-4] << 24) | ((uint32_t)p[-3] << 16) | ((uint32_t)p[-2] << 8) | (uint32_t)p[-1];
}

/** 响应帧拼装工作缓冲区（所有 LDI 命令复用） */

/**
 * @brief 构造并发送 LDI 响应帧
 * @param ch         回复目标通道
 * @param rsp_cmd    响应命令码（如 LDI_CMD_SET_IP_RSP = 0xA0）
 * @param seq        帧序号（回显请求帧的 seq）
 * @param payload    响应 DATA 域内容（可为 nullptr）
 * @param payload_len DATA 域长度（字节）
 */
static void ldi_send_response(channel_t *ch, uint8_t rsp_cmd, uint8_t seq, const uint8_t *payload, uint16_t payload_len)
{
    (void)rsp_cmd;
    osMutexAcquire(g_ldi.tx_lock, osWaitForever);

    ldi_frame_t *frame = (ldi_frame_t *)g_ldi.tx_buf;

    frame->stx[0] = 0xFF;
    frame->stx[1] = 0xFF;
    frame->ver    = 0x00;
    frame->seq    = seq;
    frame->len[0] = (uint8_t)(payload_len >> 24);
    frame->len[1] = (uint8_t)(payload_len >> 16);
    frame->len[2] = (uint8_t)(payload_len >> 8);
    frame->len[3] = (uint8_t)payload_len;

    if (payload_len > 0 && payload != nullptr)
        memcpy(frame->data_crc, payload, payload_len);

    uint16_t crc                     = crc16_xmodem(&frame->ver, sizeof(*frame) - sizeof(frame->stx) + payload_len);
    frame->data_crc[payload_len]     = (uint8_t)(crc >> 8);
    frame->data_crc[payload_len + 1] = (uint8_t)(crc & 0xFF);

    channel_send(ch, g_ldi.tx_buf, sizeof(*frame) + payload_len + 2);
    osMutexRelease(g_ldi.tx_lock);
}

/** @brief 定长 payload 响应（编译期 sizeof，类型安全） */
#define LDI_RESPOND(ch, rsp_cmd, seq, payload) \
    ldi_send_response(ch, rsp_cmd, seq, (const uint8_t *)&(payload), sizeof(payload))

/** @brief 变长 payload 响应（调用方显式传额外长度） */
#define LDI_RESPOND_EX(ch, rsp_cmd, seq, payload, extra_len) \
    ldi_send_response(ch, rsp_cmd, seq, (const uint8_t *)&(payload), sizeof(payload) + (extra_len))

/** @brief 无 payload 响应（仅帧头，如简单 ACK） */
#define LDI_RESPOND_EMPTY(ch, rsp_cmd, seq) \
    ldi_send_response(ch, rsp_cmd, seq, nullptr, 0)

/** @brief 通用错误应答：标准 head + status=01H（与 0BH 既有错误应答约定一致） */
static void _ldi_error_rsp(channel_t *ch, uint8_t rsp_cmd)
{
    ldi_status_rsp_t rsp = {.status = 0x01};
    ldi_build_rsp_head(&rsp.head, rsp_cmd);
    LDI_RESPOND(ch, rsp_cmd, g_ldi.rsp_seq, rsp);
}

/** @brief 1BH 整帧校验失败错误应答：B1H 头 + device_num=0（无逐模块状态可回） */
static void _ldi_ctrl_error_rsp(channel_t *ch)
{
    ldi_ctrl_rsp_t rsp = {0};
    ldi_build_ctrl_rsp_head(&rsp.head, LDI_CMD_CTRL_RSP);
    rsp.device_num = 0;
    LDI_RESPOND(ch, LDI_CMD_CTRL_RSP, g_ldi.rsp_seq, rsp);
}

// ============================================================================
// 命令处理函数声明与分发表
// ============================================================================

static void cmd_set_ip(channel_t *ch, void *data);
static void cmd_set_config(channel_t *ch, void *data);
static void cmd_reboot(channel_t *ch, void *data);
static void cmd_rep_ip(channel_t *ch, void *data);
static void cmd_rep_config(channel_t *ch, void *data);
static void cmd_rsp_report(channel_t *ch, void *data);
static void cmd_rsp_cert(channel_t *ch, void *data);
static void cmd_update(channel_t *ch, void *data);
static void cmd_init(channel_t *ch, void *data);
static void cmd_ctrl(channel_t *ch, void *data);
static void cmd_rep_func(channel_t *ch, void *data);
static void cmd_search(channel_t *ch, void *data);

/**
 * LDI 命令处理函数分发表
 *
 * 按命令码数组索引: data[0] 即为 cmd_type, 但实际分发由 protocol.c
 * 根据 cmd_type 查表调用, 此处顺序应与 ldi_cmd_type_t 枚举值对应.
 */
const ldi_cmd_handler_fn_t g_ldi_cmd_table[] = {
    cmd_set_ip,     // 0AH  设备IP信息设置请求
    cmd_set_config, // 0BH  设备参数配置请求
    cmd_reboot,     // 0DH  设备重启请求
    cmd_rep_ip,     // 1DH  设备IP信息采集请求
    cmd_rep_config, // 1EH  设备参数采集请求
    cmd_rsp_report, // C0H  设备状态监控上报返回
    cmd_rsp_cert,   // E0H  设备验证申请返回
    cmd_update,     // 0FH  设备升级包下载请求
    cmd_init,       // 1AH  设备初始化请求
    cmd_ctrl,       // 1BH  控制/查询请求
    cmd_rep_func,   // 1CH  设备功能数据上报
    cmd_search,     // 21H  设备搜索请求 (UDP广播)
};

// ============================================================================
// 命令处理函数实现
// ============================================================================

/**
 * @brief 保存 LDI 配置至 W25 并返回结果（0AH 如实应答用）
 *
 * 落盘字节与 app_ldi_cfg.c:app_flash_ldi_save_config 完全一致
 * （magic + cfg + CRC32，CRC 覆盖 magic+cfg 即记录总长减 crc32 字段），
 * 仅额外返回擦/写结果；save_config 为 void 且不在本次改动范围内，
 * 故此处内联其逻辑以捕获返回值，两处需保持同构。
 *
 * @return 0 成功；<0 擦除/写入失败（dev_storage_erase/write 错误码）
 */
static int32_t _ldi_save_config_ret(app_flash_ldi_cfg_info_t *info)
{
    app_flash_ldi_record_t rec = {0};
    rec.magic                  = APP_FLASH_LDI_MAGIC;
    memcpy(&rec.cfg, info, sizeof(app_flash_ldi_cfg_info_t));
    rec.crc32 = pl_crc32_calc(pl_crc_get_handle(), (uint8_t *)&rec, sizeof(rec) - sizeof(rec.crc32));

    int32_t ret = app_flash_ldi_erase_config();
    if (ret < 0)
        return ret;
    ret = app_flash_ldi_write_config(&rec);
    return ret < 0 ? ret : 0;
}

/**
 * 处理 0AH 设备 IP 信息设置请求
 *
 * 上位机→设备, 用于出厂配置模式下设置设备网络参数.
 * data 指向 cmd_set_ip_t 结构.
 *
 * 应答错误码：00H=成功, 01H=失败（与 0BH 及 ldi_status_rsp_t 既有约定一致）。
 * W25 保存或 Sector1 同步任一步失败即回 01H；固件侧不自动重试，
 * 上位机收到 01H 后重发 0AH 即可恢复（两次写入均幂等）。
 * 网络配置写入 W25+Sector1 后**重启生效**（运行时网口不即时变更，属既定策略）。
 */
void cmd_set_ip(channel_t *ch, void *data)
{
    /* data_len 下限：cmd_set_ip_t 共 85 字节（head 20 + network 65），不足回错误应答 */
    if (_ldi_data_len(data) < sizeof(cmd_set_ip_t)) {
        _ldi_error_rsp(ch, LDI_CMD_SET_IP_RSP);
        return;
    }

    cmd_set_ip_t *info = data;

    memcpy(g_ldi.cfg.device_ip, info->net.device_ip, sizeof(g_ldi.cfg.device_ip));
    g_ldi.cfg.device_port = ((uint16_t)info->net.device_port[0] << 8) | info->net.device_port[1];
    memcpy(g_ldi.cfg.host_ip, info->net.host_ip, sizeof(g_ldi.cfg.host_ip));
    g_ldi.cfg.host_port = ((uint16_t)info->net.host_port[0] << 8) | info->net.host_port[1];
    memcpy(g_ldi.cfg.netmask, info->net.netmask, sizeof(g_ldi.cfg.netmask));
    memcpy(g_ldi.cfg.gateway, info->net.gateway, sizeof(g_ldi.cfg.gateway));
    g_ldi.cfg_valid = true;

    /* 两步持久化：先 W25（LDI 完整配置），再板级网络配置（Sector1）。
     * 任一失败即如实应答失败，不再静默回 00H。
     * 方案 B（2026-08-21）：0AH 写 TCP 业务口（device_port），udp_port 保留现值
     * （get 失败用出厂默认 20103）。 */
    int32_t w25_ret    = _ldi_save_config_ret(&g_ldi.cfg);
    app_board_net_cfg_t cur_cfg;
    uint32_t udp_port = (app_board_net_cfg_get(&cur_cfg) == 0) ? cur_cfg.udp_port : 20103U;
    int32_t board_ret  = app_board_net_cfg_update(g_ldi.cfg.device_ip, g_ldi.cfg.netmask,
                                                  g_ldi.cfg.gateway, g_ldi.cfg.device_port,
                                                  udp_port);

    ldi_status_rsp_t rsp = {.status = (w25_ret < 0 || board_ret < 0) ? 0x01 : 0x00};
    ldi_build_rsp_head(&rsp.head, LDI_CMD_SET_IP_RSP);
    LDI_RESPOND(ch, LDI_CMD_SET_IP_RSP, g_ldi.rsp_seq, rsp);
}

/**
 * 处理 0BH 设备参数配置请求
 *
 * 上位机→设备, 解析复合指令的 module 序列，
 * 将每个模块的 device_type + device_index + vendor[10] 写入 Flash.
 */
static void cmd_set_config(channel_t *ch, void *data)
{
    uint32_t data_len = _ldi_data_len(data);

    /* data_len 下限：至少 head(20B) + device_num(1B) */
    if (data_len < sizeof(ldi_req_head_t) + 1) {
        _ldi_error_rsp(ch, LDI_CMD_SET_PARA_RSP);
        return;
    }

    ldi_req_head_t *head = (ldi_req_head_t *)data;
    uint8_t *ptr         = (uint8_t *)data + sizeof(ldi_req_head_t);
    uint8_t device_num   = *ptr++;

    /* 0BH 请求头部含车道编号和验证信息，与 module 数据一同持久化 */
    memcpy(g_ldi.cfg.lane_hex, head->lane_code, sizeof(g_ldi.cfg.lane_hex));
    memcpy(g_ldi.cfg.cert, head->cert_info, sizeof(g_ldi.cfg.cert));

    if (device_num == 0 || device_num > g_ldi.cfg.module_count) {
        ldi_status_rsp_t rsp = {.status = 0x01};
        ldi_build_rsp_head(&rsp.head, LDI_CMD_SET_PARA_RSP);
        LDI_RESPOND(ch, LDI_CMD_SET_PARA_RSP, g_ldi.rsp_seq, rsp);
        return;
    }

    /* 以编译期 cfg 中的 device_type 做键，匹配请求帧中的 module，同步 index 和 vendor */
    bool result = true;
    for (uint8_t i = 0; i < device_num; i++) {
        /* 每 module 先查表取长度，读取公共头与 vendor 前均校验剩余帧长，防越界读 */
        uint32_t consumed = (uint32_t)(ptr - (const uint8_t *)data);
        if (consumed + sizeof(ldi_module_head_t) > data_len) {
            result = false;
            break;
        }
        ldi_module_head_t *mod = (ldi_module_head_t *)ptr;
        uint8_t mod_size       = ldi_cfg_module_size((ldi_device_t)mod->device_type);

        if (mod_size == 0) {
            result = false;
            break;
        }
        if (consumed + mod_size > data_len) {
            result = false;
            break;
        }

        int8_t cfg_idx = -1;
        for (uint8_t j = 0; j < g_ldi.cfg.module_count; j++) {
            if (g_ldi.cfg.modules[j].device_type == mod->device_type) {
                cfg_idx = (int8_t)j;
                break;
            }
        }
        if (cfg_idx < 0) {
            result = false;
            break;
        }

        g_ldi.cfg.modules[cfg_idx].device_index = mod->device_index;
        uint8_t vendor_len                      = mod_size - sizeof(ldi_module_head_t);
        if (vendor_len > sizeof(g_ldi.cfg.modules[cfg_idx].vendor))
            vendor_len = sizeof(g_ldi.cfg.modules[cfg_idx].vendor);
        memcpy(g_ldi.cfg.modules[cfg_idx].vendor, ptr + sizeof(ldi_module_head_t), vendor_len);

        ptr += mod_size;
    }

    if (result)
        app_flash_ldi_save_config(&g_ldi.cfg);

    ldi_status_rsp_t rsp = {.status = result ? 0x00 : 0x01};
    ldi_build_rsp_head(&rsp.head, LDI_CMD_SET_PARA_RSP);
    LDI_RESPOND(ch, LDI_CMD_SET_PARA_RSP, g_ldi.rsp_seq, rsp);
}

/**
 * 处理 0DH 设备重启请求
 *
 * 上位机→设备, 可按模块指定重启范围.
 * 本 MCU 不支持部分重启，发送响应帧后执行整机软件复位.
 */
static void cmd_reboot(channel_t *ch, void *data)
{
    (void)data;

    /* D0H 响应: head(20B) + ErrorCode(1B), 简单 ACK */
    ldi_status_rsp_t rsp = {.status = 0x00};
    ldi_build_rsp_head(&rsp.head, LDI_CMD_REBOOT_RSP);
    LDI_RESPOND(ch, LDI_CMD_REBOOT_RSP, g_ldi.rsp_seq, rsp);

    osDelay(100);      // 等待以太网发送完成
    pl_system_reset(); // 整机软件复位
}

/**
 * 处理 1DH 设备 IP 信息采集请求
 *
 * 上位机→设备, DATA 域仅含通用头部, 无额外字段.
 * 设备收到后应回复当前设备的网络配置 (D1H).
 */
static void cmd_rep_ip(channel_t *ch, void *data)
{
    (void)data;
    uint8_t buf[sizeof(ldi_status_rsp_t) + sizeof(ldi_network_info_t)] = {0};

    ldi_status_rsp_t *rsp   = (ldi_status_rsp_t *)buf;
    ldi_network_info_t *net = (ldi_network_info_t *)rsp->payload;

    ldi_build_rsp_head(&rsp->head, LDI_CMD_GET_IP_RSP);
    rsp->status = 0x00;
    /* D1H DATA = head(20) | ErrorCode(1) | network block(65). */

    memcpy(net->device_ip, g_ldi.cfg.device_ip, sizeof(net->device_ip));
    net->device_port[0] = (uint8_t)(g_ldi.cfg.device_port >> 8);
    net->device_port[1] = (uint8_t)(g_ldi.cfg.device_port);
    memcpy(net->gateway, g_ldi.cfg.gateway, sizeof(net->gateway));
    memcpy(net->netmask, g_ldi.cfg.netmask, sizeof(net->netmask));
    memcpy(net->host_ip, g_ldi.cfg.host_ip, sizeof(net->host_ip));
    net->host_port[0] = (uint8_t)(g_ldi.cfg.host_port >> 8);
    net->host_port[1] = (uint8_t)(g_ldi.cfg.host_port);

    LDI_RESPOND_EX(ch, LDI_CMD_GET_IP_RSP, g_ldi.rsp_seq, *rsp, sizeof(ldi_network_info_t));
}

/**
 * 处理 1EH 设备参数采集请求
 *
 * 上位机→设备, DATA 域仅含通用头部.
 * 设备收到后回复 E1H: head(20B) + device_num(1B) + N×module(变长).
 *
 * 各设备 module 结构与 0BH 设置时一致, vendor 长度为 2~10 字节不等,
 * 通过 ldi_cfg_module_size() 查表确定.
 */
static void cmd_rep_config(channel_t *ch, void *data)
{
    (void)data;

    // 计算所有 module 的总字节数，确定局部 buffer 大小
    uint16_t modules_len = 0;
    for (uint8_t i = 0; i < g_ldi.cfg.module_count; i++) {
        uint8_t mod_size = ldi_cfg_module_size((ldi_device_t)g_ldi.cfg.modules[i].device_type);
        // Flash 最多存 10 字节 vendor，超出则按 Flash 实际容量截断
        uint8_t vendor_len = mod_size - sizeof(ldi_module_head_t);
        if (vendor_len > sizeof(g_ldi.cfg.modules[i].vendor))
            vendor_len = sizeof(g_ldi.cfg.modules[i].vendor);
        modules_len += sizeof(ldi_module_head_t) + vendor_len;
    }

    // 用局部 buffer 组装完整 DATA（含 head）
    // 避免与 tx_buf 的 DATA 写入区重叠
    uint8_t buf[sizeof(ldi_rep_config_rsp_t) + modules_len];
    ldi_rep_config_rsp_t *rsp = (ldi_rep_config_rsp_t *)buf;

    ldi_build_rsp_head(&rsp->head, LDI_CMD_GET_PARA_RSP);
    rsp->device_num = g_ldi.cfg.module_count;

    uint8_t *dst = rsp->modules;
    for (uint8_t i = 0; i < g_ldi.cfg.module_count; i++) {
        app_flash_ldi_module_cfg_t *mod = &g_ldi.cfg.modules[i];

        // module 公共头
        *dst++ = mod->device_type;
        *dst++ = mod->device_index;

        // 查表确定 vendor 实际长度
        uint8_t mod_size   = ldi_cfg_module_size((ldi_device_t)mod->device_type);
        uint8_t vendor_len = mod_size - sizeof(ldi_module_head_t);
        if (vendor_len > sizeof(mod->vendor))
            vendor_len = sizeof(mod->vendor);

        memcpy(dst, mod->vendor, vendor_len);
        dst += vendor_len;
    }

    LDI_RESPOND_EX(ch, LDI_CMD_GET_PARA_RSP, g_ldi.rsp_seq, *rsp, modules_len);
}

/**
 * 处理 C0H 设备状态监控上报确认
 *
 * 设备确认上位机收到的上报
 */
static void cmd_rsp_report(channel_t *ch, void *data)
{
    (void)ch;

    /* data_len 下限：C0H 是服务端对设备上报的应答，协议无再应答约定，
     * 不足 head(20B) 时静默丢弃（无法回错误应答） */
    if (_ldi_data_len(data) < sizeof(ldi_req_head_t))
        return;

    /* C0H 是服务器对设备上报的应答，每 5 秒一次，携带服务器 Unix 时间戳，用于定期对钟 */
    ldi_req_head_t *head = (ldi_req_head_t *)data;
    uint32_t ts          = ((uint32_t)head->unix_timestamp[0] << 24) |
                           ((uint32_t)head->unix_timestamp[1] << 16) |
                           ((uint32_t)head->unix_timestamp[2] << 8) |
                           (uint32_t)head->unix_timestamp[3];
    pl_rtc_set_timestamp(pl_rtc_get_handle(), ts);
}

/* ================================================================
 *  主动发送帧（设备 → 上位机）
 *
 *  当前仅在 TCP Client 通道上发送，由 ldi_timer_task 周期驱动。
 *  ldi_next_rpt_seq() 返回 0x10~0xF0 的主动发送序号。
 *  ldi_build_rsp_head() 从内部状态构建头部（RTC + g_ldi.cfg）。
 * ================================================================ */

/**
 * @brief 发送 0EH 设备验证申请
 *
 * DATA = head(20B) + device_num(1B) + N×(device_type + device_index)(2B)
 * 上电后每 3 秒发送一次，直到收到 E0H 认证成功。
 * server 根据 lane_code/cert_info 和设备列表验证设备身份。
 */
void ldi_send_cert_req(channel_t *ch)
{
    uint8_t buf[sizeof(ldi_cert_req_t) + APP_FLASH_LDI_MAX_MODULES * 2];
    ldi_cert_req_t *req = (ldi_cert_req_t *)buf;

    ldi_build_rsp_head(&req->head, LDI_CMD_CERT_REQ);
    req->device_num = g_ldi.cfg.module_count;

    for (uint8_t i = 0; i < g_ldi.cfg.module_count; i++) {
        req->devices[i].device_type  = g_ldi.cfg.modules[i].device_type;
        req->devices[i].device_index = g_ldi.cfg.modules[i].device_index;
    }

    uint16_t payload_len = sizeof(ldi_cert_req_t) + g_ldi.cfg.module_count * 2;
    uint8_t seq          = ldi_next_rpt_seq();
    ldi_send_response(ch, LDI_CMD_CERT_REQ, seq, (const uint8_t *)req, payload_len);
}

/**
 * @brief 发送 0CH 设备状态监控上报
 *
 * DATA = head(20B) + RunningTime(4B) + RunningStatus(1B) + ConnectStatus(1B) + DeviceNum(1B) + DeviceInfo[N×17B]
 * 认证成功后每 5 秒发送一次。
 */
void ldi_send_sta_rpt(channel_t *ch)
{
    uint8_t buf[sizeof(ldi_sta_rpt_t) + APP_FLASH_LDI_MAX_MODULES * sizeof(ldi_device_info_t)];
    ldi_sta_rpt_t *rpt = (ldi_sta_rpt_t *)buf;

    ldi_build_rsp_head(&rpt->head, LDI_CMD_STA_RPT_REQ);

    /* RunningTime：设备自 RTOS 启动以来的运行秒数 */
    uint32_t rt          = osKernelGetTickCount() / 1000;
    rpt->running_time[0] = (uint8_t)(rt >> 24);
    rpt->running_time[1] = (uint8_t)(rt >> 16);
    rpt->running_time[2] = (uint8_t)(rt >> 8);
    rpt->running_time[3] = (uint8_t)rt;

    rpt->running_status = 0x00; /* 暂填正常 */
    rpt->connect_status = 0x00; /* 暂填已连接 */
    rpt->device_num     = g_ldi.cfg.module_count;

    /* 从 RTC 反推当前日期，转为 BCD 码（每字节 = 十位<<4 | 个位）
     * 例: 2026-05-13 → {0x20, 0x26, 0x05, 0x13} */
    time_t ts_now = (time_t)pl_rtc_get_timestamp(pl_rtc_get_handle());
    struct tm *tm = gmtime(&ts_now);
    uint16_t yr   = (uint16_t)(tm->tm_year + 1900); // uint8_t 装不下 2026，会溢出
    uint8_t dt[4] = {
        (uint8_t)((yr / 100 / 10 << 4) | (yr / 100 % 10)),                 // 世纪 BCD（如 20→0x20）
        (uint8_t)((yr % 100 / 10 << 4) | (yr % 100 % 10)),                 // 年份 BCD（如 26→0x26）
        (uint8_t)(((tm->tm_mon + 1) / 10 << 4) | ((tm->tm_mon + 1) % 10)), // 月份 BCD
        (uint8_t)((tm->tm_mday / 10 << 4) | (tm->tm_mday % 10)),           // 日期 BCD
    };

    for (uint8_t i = 0; i < g_ldi.cfg.module_count; i++) {
        rpt->devices[i].device_type      = g_ldi.cfg.modules[i].device_type;
        rpt->devices[i].device_index     = g_ldi.cfg.modules[i].device_index;
        rpt->devices[i].available_status = 0x00; /* 暂填可用 */
        rpt->devices[i].error_code       = 0x00;
        rpt->devices[i].running_status   = 0x01;
        /* E6/E7/E8：用设备能力层真实状态覆盖默认值 */
        (void)ldi_device_fill_sta(g_ldi.cfg.modules[i].device_type, &rpt->devices[i]);
        rpt->devices[i].vendor_code[0]   = '0'; /* 暂填默认厂商代码 */
        rpt->devices[i].vendor_code[1]   = '7';
        rpt->devices[i].model_code[0]    = '2'; /* 暂填默认型号代码 */
        rpt->devices[i].model_code[1]    = '1';
        memcpy(rpt->devices[i].date_bcd, dt, sizeof(dt));
        rpt->devices[i].version_serial = 0x01; /* 暂填默认版本 */
        memset(rpt->devices[i].reserved, 0, sizeof(rpt->devices[i].reserved));
    }

    uint16_t payload_len = sizeof(ldi_sta_rpt_t) + g_ldi.cfg.module_count * sizeof(ldi_device_info_t);
    uint8_t seq          = ldi_next_rpt_seq();
    ldi_send_response(ch, LDI_CMD_STA_RPT_REQ, seq, (const uint8_t *)rpt, payload_len);
}

/**
 * 处理 E0H 设备验证结果
 *
 * 设备收到上位机回复的验证结果
 */
static void cmd_rsp_cert(channel_t *ch, void *data)
{
    (void)ch;

    /* data_len 下限：head(20B) + error_code(1B) 偏移读；
     * E0H 同为服务端应答，无再应答约定，不足静默丢弃 */
    if (_ldi_data_len(data) < sizeof(ldi_req_head_t) + 1)
        return;

    /* E0H 响应：head(20B) + error_code(1B)，同步时间戳并检查认证结果 */
    ldi_req_head_t *head = (ldi_req_head_t *)data;
    uint32_t ts          = ((uint32_t)head->unix_timestamp[0] << 24) |
                           ((uint32_t)head->unix_timestamp[1] << 16) |
                           ((uint32_t)head->unix_timestamp[2] << 8) |
                           (uint32_t)head->unix_timestamp[3];
    pl_rtc_set_timestamp(pl_rtc_get_handle(), ts); // 调试：排除 RTC 并发写

    uint8_t error_code = *((uint8_t *)data + sizeof(ldi_req_head_t));
    if (error_code == 0x00)
        g_ldi.state = LDI_ST_AUTHED;
}

/**
 * 处理 0FH 设备升级包下载请求
 *
 * 升级不在本协议中实现，这里只定义桩函数
 */
static void cmd_update(channel_t *ch, void *data)
{
    (void)ch;
    (void)data;
}

/**
 * 处理 1AH 设备初始化请求
 *
 * 上位机→设备, 在设备验证成功后发起.
 * 请求帧: head(20B) | device_num(1B) | module[0] | ... | module[N-1]
 * 每个 module: device_type(1B) | device_index(1B) | version(1B) | custom_init(n)
 *
 * 响应 A1H: head(20B) | device_num(1B) | module[0] | ... | module[N-1]
 * 每个 module: device_type(1B) | device_index(1B) | protocol_version(2B) |
 *              custom_init_len(1B) | custom_init(变长)
 *
 * 当前无个性化初始化内容, 每个响应 module 固定 5 字节.
 */
static void cmd_init(channel_t *ch, void *data)
{
    uint32_t data_len = _ldi_data_len(data);

    /* data_len 下限：至少 head(20B) + device_num(1B) */
    if (data_len < sizeof(ldi_req_head_t) + 1) {
        _ldi_error_rsp(ch, LDI_CMD_INIT_RSP);
        return;
    }

    uint8_t *ptr       = (uint8_t *)data + sizeof(ldi_req_head_t);
    uint8_t device_num = *ptr++;

    /* device_num 钳制 ≤ 设备类型上限（LDI_DEV_TYPE_COUNT=13），超限视为非法帧回错误应答，
     * 同时防止响应缓冲 VLA 尺寸被恶意 device_num 撑爆 */
    if (device_num > LDI_DEV_TYPE_COUNT) {
        _ldi_error_rsp(ch, LDI_CMD_INIT_RSP);
        return;
    }

    // 每个响应 module 定长 10 字节 (custom_init_len=0)
    uint8_t buf[sizeof(ldi_init_rsp_t) + device_num * sizeof(ldi_init_rsp_module_t)];
    ldi_init_rsp_t *rsp = (ldi_init_rsp_t *)buf;
    ldi_build_rsp_head(&rsp->head, LDI_CMD_INIT_RSP);
    rsp->device_num = device_num;

    bool all_ok                    = true;
    ldi_init_rsp_module_t *dst_mod = (ldi_init_rsp_module_t *)rsp->modules;
    for (uint8_t i = 0; i < device_num; i++) {
        /* 每请求 module 定长 5 字节：head(2) + protocol_version(2) + custom_init_len(1) */
        uint32_t consumed = (uint32_t)(ptr - (const uint8_t *)data);
        if (data_len - consumed < sizeof(ldi_module_head_t) + 2 + 1) {
            _ldi_error_rsp(ch, LDI_CMD_INIT_RSP);
            return;
        }
        ldi_module_head_t *req_mod = (ldi_module_head_t *)ptr;

        // 响应 module 头部
        dst_mod->head.device_type  = req_mod->device_type;
        dst_mod->head.device_index = req_mod->device_index;

        // 验证 device_type 是否在设备注册表中
        bool found = false;
        for (uint8_t j = 0; j < g_ldi.cfg.module_count; j++) {
            if (g_ldi.cfg.modules[j].device_type == (ldi_device_t)req_mod->device_type) {
                found = true;
                break;
            }
        }
        dst_mod->status = found ? 0x00 : 0x01;
        if (!found) all_ok = false;

        // 从请求模块中读取 protocol_version (2字节) 和 custom_init_len (1字节)
        uint8_t *mod_data = ptr + sizeof(ldi_module_head_t);
        uint8_t protocol_version[2] = {mod_data[0], mod_data[1]};
        uint8_t custom_init_len = mod_data[2];

        /* custom_init_len 校验：不得超过剩余帧长（防 ptr 推进越出帧尾） */
        uint32_t fixed_part = sizeof(ldi_module_head_t) + 2 + 1;
        if (custom_init_len > data_len - consumed - fixed_part) {
            _ldi_error_rsp(ch, LDI_CMD_INIT_RSP);
            return;
        }

        // 版本号（从请求中读取）
        dst_mod->software_version[0] = 0x00; // 暂填默认值
        dst_mod->software_version[1] = 0x01;
        dst_mod->firmware_version[0] = 0x00;
        dst_mod->firmware_version[1] = 0x01;
        dst_mod->protocol_version[0] = protocol_version[0];
        dst_mod->protocol_version[1] = protocol_version[1];
        dst_mod->custom_init_len     = 0x00; // 当前无个性化内容，忽略请求中的 custom_init

        // 推进: 请求帧 module (5字节 + custom_init_len) → 响应 module (10字节)
        ptr += fixed_part + custom_init_len;
        dst_mod = (ldi_init_rsp_module_t *)((uint8_t *)dst_mod + sizeof(ldi_init_rsp_module_t));
    }

    uint16_t modules_len = (uint16_t)((uint8_t *)dst_mod - rsp->modules);
    LDI_RESPOND_EX(ch, LDI_CMD_INIT_RSP, g_ldi.rsp_seq, *rsp, modules_len);

    if (all_ok)
        g_ldi.state = LDI_ST_READY;
}

/**
 * 处理 1BH 控制/查询请求
 *
 * 上位机→设备, 支持单次对多个功能模块进行组合控制或查询.
 * 请求: ctrl_head(24B) | device_num(1B) | Σ[mod_len(2B大端) | mod子帧]
 * 每个 mod 子帧 = DeviceType | DeviceIndex | DeviceFuncType | 功能payload
 * 响应 B1H: ctrl_head(24B) | device_num(1B) | N × ldi_ctrl_rsp_payload_t(4B)
 */
static void cmd_ctrl(channel_t *ch, void *data)
{
    uint32_t data_len = _ldi_data_len(data);

    /* data_len 下限：至少 ctrl_head(24B) + device_num(1B) */
    if (data_len < sizeof(ldi_ctrl_head_t) + 1) {
        _ldi_ctrl_error_rsp(ch);
        return;
    }

    // 1BH 使用 24 字节 ctrl_head (UnixTimestamp 8B)，不沿用 ldi_req_head_t
    uint8_t *ptr       = (uint8_t *)data + sizeof(ldi_ctrl_head_t);
    uint8_t device_num = *ptr++;

    /* device_num 钳制 ≤ 设备类型上限（LDI_DEV_TYPE_COUNT=13），越界回错误应答，
     * 同时防响应缓冲 VLA 尺寸被恶意 device_num 撑爆 */
    if (device_num > LDI_DEV_TYPE_COUNT) {
        _ldi_ctrl_error_rsp(ch);
        return;
    }

    /* 响应总长防御钳制 ≤ tx_buf 容量（LDI_TX_BUF_SIZE=512），超限回错误应答。
     * device_num 已钳制 ≤13，响应最长 25+13×4=77 字节恒不超限，保留防御 */
    if (sizeof(ldi_ctrl_rsp_t) + (uint32_t)device_num * sizeof(ldi_ctrl_rsp_payload_t) > LDI_TX_BUF_SIZE) {
        _ldi_ctrl_error_rsp(ch);
        return;
    }

    uint8_t buf[sizeof(ldi_ctrl_rsp_t) + device_num * sizeof(ldi_ctrl_rsp_payload_t)];
    ldi_ctrl_rsp_t *rsp = (ldi_ctrl_rsp_t *)buf;
    ldi_build_ctrl_rsp_head(&rsp->head, LDI_CMD_CTRL_RSP);
    rsp->device_num = device_num;

    for (uint8_t i = 0; i < device_num; i++) {
        uint32_t consumed = (uint32_t)(ptr - (const uint8_t *)data);

        /* mod_len 读取需 2 字节，module 子帧必须完整落在帧内 */
        if (consumed + 2 > data_len) {
            _ldi_ctrl_error_rsp(ch);
            return;
        }
        // mod_len: module 子帧总长 (含 DeviceType + DeviceIndex + payload)，大端序
        uint16_t mod_len = ((uint16_t)ptr[0] << 8) | ptr[1];
        ptr += 2;
        consumed += 2;

        /* mod_len 至少含 module 公共头(2B) + DeviceFuncType(1B)，且不超过剩余帧长，
         * 越界回错误应答（防 ptr 推进越出帧尾 / 后续读取越界） */
        if (mod_len < sizeof(ldi_module_head_t) + 1 || consumed + mod_len > data_len) {
            _ldi_ctrl_error_rsp(ch);
            return;
        }

        ldi_module_head_t *mod = (ldi_module_head_t *)ptr;
        uint8_t *payload       = ptr + sizeof(ldi_module_head_t);

        // 填充响应 module 公共字段
        rsp->modules[i].device_type      = mod->device_type;
        rsp->modules[i].device_index     = mod->device_index;
        rsp->modules[i].device_func_type = *payload;

        // 校验 device_type 是否在设备注册表中
        bool found = false;
        for (uint8_t j = 0; j < g_ldi.cfg.module_count; j++) {
            if (g_ldi.cfg.modules[j].device_type == (ldi_device_t)mod->device_type) {
                found = true;
                break;
            }
        }
        rsp->modules[i].status = found ? 0x00 : 0x01;

        // 解析设备特定 payload，当前仅做结构校验，硬件控制后续实现
        switch (mod->device_type) {
            case LDI_DEV_TYPE_BARRIER: { // E4H 栏杆控制 (01H)
                ldi_ctrl_barrier_t *ctrl = (ldi_ctrl_barrier_t *)payload;
                (void)ctrl; // TODO: dev_barrier_ctrl(ctrl->status)
                break;
            }
            case LDI_DEV_TYPE_VD: { // E5H 车检 (02H)，无额外 payload
                (void)payload;      // TODO: dev_vd_defog()
                break;
            }
            case LDI_DEV_TYPE_DISPLAY: { // E6H 显示控制(01H) / 清屏(02H)
                ldi_ctrl_display_t *ctrl = (ldi_ctrl_display_t *)payload;
                uint16_t text_len = 0;
                if (ctrl->device_func_type == 0x01) {
                    /* mod_len 含 DeviceType+Index+定长头；text 为柔性尾部 */
                    uint16_t fixed = sizeof(ldi_module_head_t) + sizeof(ldi_ctrl_display_t);
                    text_len = (mod_len > fixed) ? (uint16_t)(mod_len - fixed) : 0;
                }
                if (ldi_device_display_ctrl(ctrl, text_len) != LDI_DEV_OK)
                    rsp->modules[i].status = 0x01;
                break;
            }
            case LDI_DEV_TYPE_LANE_SIGNAL: { // E7H 信号灯控制 (01H)
                ldi_ctrl_signal_t *ctrl = (ldi_ctrl_signal_t *)payload;
                if (ldi_device_lane_signal_ctrl(ctrl) != LDI_DEV_OK)
                    rsp->modules[i].status = 0x01;
                break;
            }
            case LDI_DEV_TYPE_ALARM: { // E8H 报警控制 (01H)
                ldi_ctrl_alarm_t *ctrl = (ldi_ctrl_alarm_t *)payload;
                if (ldi_device_alarm_ctrl(ctrl) != LDI_DEV_OK)
                    rsp->modules[i].status = 0x01;
                break;
            }
            case LDI_DEV_TYPE_VMS: { // E9H → VMS (01H)
                ldi_ctrl_vms_t *ctrl = (ldi_ctrl_vms_t *)payload;
                /* mod_len 小于定长部分（head 2B + ldi_ctrl_vms_t 6B）时不再下溢相减
                 * （uint16 回绕会向 vms_ctrl 传出巨值 text_len 越界读），直接标记失败 */
                uint16_t fixed = sizeof(ldi_ctrl_vms_t) + sizeof(ldi_module_head_t);
                if (mod_len < fixed)
                    rsp->modules[i].status = 0x01;
                else
                    vms_ctrl(ctrl, (uint16_t)(mod_len - fixed));
                break;
            }
            case LDI_DEV_TYPE_CANOPY_LIGHT: { // EAH 雨棚灯控制 (01H)
                ldi_ctrl_canopy_light_t *ctrl = (ldi_ctrl_canopy_light_t *)payload;
                (void)ctrl; // TODO: dev_canopy_light_ctrl(ctrl->color)
                break;
            }
            case LDI_DEV_TYPE_FOG_LIGHT: { // EBH 雾灯控制 (01H)
                ldi_ctrl_fog_light_t *ctrl = (ldi_ctrl_fog_light_t *)payload;
                (void)ctrl; // TODO: dev_fog_light_ctrl(ctrl)
                break;
            }
            case LDI_DEV_TYPE_VOICE: { // F4H 语音播报 (01H)
                ldi_ctrl_voice_t *ctrl = (ldi_ctrl_voice_t *)payload;
                (void)ctrl; // TODO: dev_voice_ctrl(ctrl)
                break;
            }
            default:
                break;
        }

        ptr += mod_len;
    }

    LDI_RESPOND_EX(ch, LDI_CMD_CTRL_RSP, g_ldi.rsp_seq, *rsp, device_num * sizeof(ldi_ctrl_rsp_payload_t));
}

/**
 * 处理 1CH 设备功能数据上报
 *
 * 设备→上位机, 主动上报含 N 个功能模块信息的数据帧.
 * 上位机处理完成后回复 C1H (上报确认).
 */
static void cmd_rep_func(channel_t *ch, void *data)
{
    (void)ch;
    (void)data;
}

/**
 * 处理 21H 设备搜索请求（创迪发现口，默认 UDP/10011）
 *
 * 回复 12H: CmdType(1) + IP(4) + Port(2) + Gateway(4) + Mask(4) + ErrCode(1)
 * 广播为主（2026-08-21：搜索应答面向广播工具，广播复用常驻通道 conn 不占
 * netconn 池，是可靠路径），回源单播仅容错、失败静默——回源依赖通道级
 * src 快照，多协议交错（10011 同口承载 LDI/IAP/CQ）下可能发错目标。
 * 不承担业务控制；网络参数取自 g_ldi.cfg（无配置时回退 pl_net 当前值）。
 */
static void cmd_search(channel_t *ch, void *data)
{
    (void)data;

    ldi_search_rsp_t rsp = {
        .cmd_type = LDI_CMD_SEARCH_RSP,
        .err_code = 0x00,
    };

    uint8_t ip[4] = {0}, mask[4] = {0}, gw[4] = {0};
    if (g_ldi.cfg_valid) {
        memcpy(ip, g_ldi.cfg.device_ip, 4);
        memcpy(mask, g_ldi.cfg.netmask, 4);
        memcpy(gw, g_ldi.cfg.gateway, 4);
    } else {
        pl_net_get_ip(ip, mask, gw);
    }

    memcpy(rsp.ip, ip, sizeof(rsp.ip));
    /* 12H 应答 Port 字段语义 = 设备「配置功能端口」（TCP 业务端口，出厂默认 9528，
     * 协议文档 doc/02 附件2），非 UDP 发现口 10011。取 g_ldi.cfg 的 device_port，
     * 未配置时回退出厂默认 9528——此前误用 LDI_DISCOVERY_PORT 导致上位机把 10011
     * 当配置端口读回并写回，污染 Sector1/W25 后 TCP Server 错误改监听 10011。 */
    uint16_t port = g_ldi.cfg_valid ? g_ldi.cfg.device_port : LDI_DEFAULT_CONFIG_PORT;
    rsp.port[0]   = (uint8_t)(port >> 8);
    rsp.port[1]   = (uint8_t)port;
    memcpy(rsp.gateway, gw, sizeof(rsp.gateway));
    memcpy(rsp.mask, mask, sizeof(rsp.mask));

    uint16_t payload_len = sizeof(ldi_search_rsp_t);
    uint16_t frame_len   = (uint16_t)(sizeof(ldi_frame_t) + payload_len + 2);

    osMutexAcquire(g_ldi.tx_lock, osWaitForever);
    ldi_frame_t *frame = (ldi_frame_t *)g_ldi.tx_buf;
    frame->stx[0]      = 0xFF;
    frame->stx[1]      = 0xFF;
    frame->ver         = 0x00;
    frame->seq         = ldi_next_rpt_seq();
    frame->len[0]      = (uint8_t)(payload_len >> 24);
    frame->len[1]      = (uint8_t)(payload_len >> 16);
    frame->len[2]      = (uint8_t)(payload_len >> 8);
    frame->len[3]      = (uint8_t)payload_len;
    memcpy(frame->data_crc, &rsp, payload_len);
    uint16_t crc                     = crc16_xmodem(&frame->ver, sizeof(*frame) - sizeof(frame->stx) + payload_len);
    frame->data_crc[payload_len]     = (uint8_t)(crc >> 8);
    frame->data_crc[payload_len + 1] = (uint8_t)(crc & 0xFF);

    /* 发送顺序：广播为主、回源为辅（2026-08-21）。
     * 回源依赖通道 src 快照（s_udp_ch.src_ip/src_port），LDI 帧排队处理期间
     * 10011 上后续 IAP/CQ 帧会覆盖快照 → 回源可能发错目标，故先发广播保证
     * 搜索工具必达，回源仅容错且失败静默。帧级 src 快照（frame_msg_t 扩展）
     * 属架构改造，本轮不做，留作已知限制（doc/07）。 */
    app_udp_broadcast(g_ldi.tx_buf, frame_len);

    if (ch != NULL && ch->ops != NULL && ch->ops->send != NULL)
        (void)channel_send(ch, g_ldi.tx_buf, frame_len);

    osMutexRelease(g_ldi.tx_lock);
}
