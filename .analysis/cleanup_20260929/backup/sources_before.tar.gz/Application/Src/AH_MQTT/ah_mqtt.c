#include "ah_mqtt.h"

#include "FreeRTOS.h"
#include "ah_mqtt_cmd.h"
#include "dev_display.h"
#include "app_mqtt.h"
#include "initcall.h"
#include "app_dispatch.h"

/* RJ45 物理通道 RB：与 IAP/LDI 等同槽 weak 合并（启用 MQTT 时才占体） */
RB_PROVIDE_WEAK(rb_provide_rj45, RB_SIZE_RJ45);

static proto_mask_t s_ah_mqtt_mask;

osMessageQueueId_t g_proto_ah_matt_queue;

topic_info_t topic_info = {
    .station_hex = "11451419",
    .lane_hex    = "01",
    .device_type = "32",
    .device_id   = "01",
};

notify_date_t notify_date = {
    .year  = "2025",
    .month = "03",
    .day   = "05",
    .hour  = "14",
};

notify_id_t xNotifyID = {
    .date_time = {
        .year  = "2025",
        .month = "03",
        .day   = "05",
        .hour  = "14",
    },
    .device_type = "32",
    .device_id   = "01",
    .send_count  = "000000",
};

osThreadId_t g_ah_mqtt_task_handle;
const osThreadAttr_t ProtocolTask_attributes = {
    .name       = "ah_mqtt_handle_task",
    .stack_size = 256 * 4, /* 与其它协议任务对齐；启用前仍须测水位 */
    .priority   = (osPriority_t)osPriorityNormal,
};

osThreadId_t SignUpHandle;
const osThreadAttr_t SignUpTask_attributes = {
    .name       = "SignUpTask",
    .stack_size = 256 * 4,
    .priority   = (osPriority_t)osPriorityLow,
};

osThreadId_t ReportHandle;
const osThreadAttr_t ReportTask_attributes = {
    .name       = "ReportTask",
    .stack_size = 256 * 4,
    .priority   = (osPriority_t)osPriorityLow,
};

static void SignUpTask(void *argument);
static void ReportTask(void *argument);
static uint8_t handle_topic(const char topic[]);

void ah_mqtt_handle_task(void *argument)
{
    (void)argument;
#define AH_MQTT_PAYLOAD_MAX (533U) /* MQTT_FRAME_MAX_LEN */
#define AH_MQTT_MSG_SIZE    (sizeof(frame_msg_t) + AH_MQTT_PAYLOAD_MAX)
#define AH_MQTT_QUEUE_DEPTH (3U)
    static uint8_t _msg_buf[AH_MQTT_MSG_SIZE];
    frame_msg_t *msg = (frame_msg_t *)_msg_buf;
    static StaticQueue_t s_ah_mqtt_queue_cb;
    static uint8_t s_ah_mqtt_queue_buf[AH_MQTT_QUEUE_DEPTH * AH_MQTT_MSG_SIZE];
    static const osMessageQueueAttr_t s_ah_mqtt_queue_attr = {
        .name    = "g_proto_ah_matt_queue",
        .cb_mem  = &s_ah_mqtt_queue_cb,
        .cb_size = sizeof(s_ah_mqtt_queue_cb),
        .mq_mem  = s_ah_mqtt_queue_buf,
        .mq_size = sizeof(s_ah_mqtt_queue_buf),
    };
    g_proto_ah_matt_queue = osMessageQueueNew(AH_MQTT_QUEUE_DEPTH, AH_MQTT_MSG_SIZE, &s_ah_mqtt_queue_attr);
    app_proto_set_frame_queue(s_ah_mqtt_mask, g_proto_ah_matt_queue);

    while (g_mqtt.state != MQTT_ST_READY) {
        osDelay(100);
    }
    SignUpHandle = osThreadNew(SignUpTask, NULL, &SignUpTask_attributes);
    ReportHandle = osThreadNew(ReportTask, NULL, &ReportTask_attributes);

    for (;;) {
        if (osOK != osMessageQueueGet(g_proto_ah_matt_queue, msg, NULL, osWaitForever)) {
            continue;
        }

        uint16_t cmd = handle_topic(container_of(msg->ch, mqtt_channel_t, me)->topic);

        g_ah_mqtt_cmd_table[cmd](msg->ch, (char *)(msg->data));
    }
}

/**
 * @brief 解析topic确认是哪个命令
 *
 */
uint8_t handle_topic(const char topic[])
{
    if (NULL != strstr(topic, "/ASK/board/NULL"))
        return 1;

    else if (NULL != strstr(topic, "/ASK/display/clean"))
        return 2;

    else if (NULL != strstr(topic, "/ASK/op/restart"))
        return 3;

    else if (NULL != strstr(topic, "/ASK/op/checktime"))
        return 4;

    else
        return 0;
}

proto_probe_sta_t ah_mqtt_probe_frame(const channel_t *ch, const ring_buffer_t *buff, uint32_t *payload_len, uint8_t *cmd_num)
{
    /* MQTT 通道在 PUBLISH 完成后已将完整 payload 写入本通道 RB；按 RB 契约探测 */
    uint32_t avail = rb_avail(buff, nullptr);
    if (avail == 0)
        return PROTO_PROBE_FAKE;

    *payload_len = avail;
    *cmd_num     = handle_topic(container_of(ch, mqtt_channel_t, me)->topic);
    return PROTO_PROBE_READY;
}

void ReportTask(void *argument)
{
    (void)argument;
    static char topic[64] = {0};
    snprintf(topic, 64, "%.8s/%.2s/%.2s/%.2s/Push/monitor/devstatus",
             topic_info.station_hex,
             topic_info.lane_hex,
             topic_info.device_type,
             topic_info.device_id);

    static state_report_t report = {
        .work_sta = '0',
        .reserved = "00000000",
    };

    for (;;) {
        memcpy(&(report.notify), &xNotifyID, sizeof(report.notify));
        /* 无显示驱动构建：无显示对象 → run_sta 报 '0'（与「屏未开」同义）；
         * 有显示时与改动前逐条一致（light_level 非 0 → '1'）。 */
        const dev_display_t *disp = dev_display_get();
        report.run_sta = (disp != nullptr && disp->light_level != 0U) ? '1' : '0'; // 根据当前亮度判断是否开显示屏
        mqtt_send_data(topic, (char *)&report);
        osDelay(10 * 1000); // 10秒签到1次
    }
}

void SignUpTask(void *argument)
{
    (void)argument;
    static char topic[64] = {0};
    snprintf(topic, 64, "%.8s/%.2s/%.2s/%.2s/Push/monitor/sign",
             topic_info.station_hex,
             topic_info.lane_hex,
             topic_info.device_type,
             topic_info.device_id);

    static sign_up_t sign_up = {
        .type         = '1',
        .work_sta     = '0',
        .soft_ver     = "SoftV1.0.0",
        .hard_ver     = "FirmwareV1",
        .protocol_ver = "LEDV1.0.00",
        .company      = "CQChuangDi",
        .device       = "LEDScreen1",
        .reserved     = "00000000000000000000",
    };
    memcpy(&(sign_up.notify), &xNotifyID, sizeof(sign_up.notify));
    mqtt_send_data(topic, (char *)&sign_up);
    sign_up.type = '0';

    for (;;) {
        osDelay(5 * 60 * 1000); // 5分钟签到1次
        memcpy(&(sign_up.notify), &xNotifyID, sizeof(sign_up.notify));
        mqtt_send_data(topic, (char *)&sign_up);
    }
}

/* ---- 自注册到 app_dispatch ---- */
[[maybe_unused]] static void ah_mqtt_module_init(void)
{
    /* MQTT 走 RJ45 共享槽；probe 须首字节快拒后方可与 IAP/LDI 同链 */
    ring_buffer_t *rb = app_proto_acquire_buf(RB_SLOT_RJ45, RB_SIZE_RJ45);
    if (rb == nullptr)
        return;

    s_ah_mqtt_mask = app_proto_register(ah_mqtt_probe_frame, rb);
    if (s_ah_mqtt_mask == 0)
        return;

    app_proto_bind_channel(s_ah_mqtt_mask, CH_ID_MQTT);

    g_ah_mqtt_task_handle = osThreadNew(ah_mqtt_handle_task, NULL, &ProtocolTask_attributes);
}
// sw_app_initcall(ah_mqtt_module_init); /* 产品未启用 MQTT 时保持注释 */
