/**
 * @file    app_factory_test_mm.c
 * @brief   出厂检测（缅甸版）— TEST 键切换 0x0A / 0x0B 箭头落点
 *
 * 与标准版 `Application/Src/app_factory_test.c` **二选一编译**（同族互斥）：
 *   · Makefile：`FACTORY ?= STD`（默认，保持改动前行为）/ `FACTORY=MM`
 *     （非法值 $(error)；开关值进口径指纹 `.build_stamp`，切口径必然全量重编 + 重链接）；
 *   · EIDE：`targets.<目标>.excludeList` 里**恰好排除一个**（Debug / Myanmar 目标
 *     均编入本文件、排除标准版，见 `.eide/eide.yml` 与 doc/16 §13）；
 *   · **天然守卫**：两文件同时编入 → 链接期 `multiple definition of
 *     'app_factory_mode_interrupt'`（同名同签名对策，无需额外守卫宏）。
 *
 * ---- 对外符号（与标准版**同名同义**，保证 `app_dispatch.c` / `app_cq_proto.c`
 *      等调用点两口径都能链接）----
 *   `app_factory_mode_interrupt()` —— 业务数据到达中止钩子；缅甸版无序列可中止 ⇒ **空实现**
 *     （保留函数体仅为满足契约；语义见下）。
 *   `app_factory_test_active()`   —— 工厂测试激活查询（CQ 心跳据此暂停计数）；缅甸版
 *     不占用显示资源、不进入任何检测序列 ⇒ **恒 false**（心跳计数照常，语义诚实）。
 *   `g_factory_test`              —— 监控任务句柄（标准版同名的运行时变量；本工程无外部
 *     引用者，保留仅为「同一套对外符号」）。
 *
 * ---- TEST 键行为（本文件与标准版的**唯一语义差异**）----
 *   按下 → `mm_arrow_map_toggle()`：把 0x0A / 0x0B 两条命令的干接点落点互换，再按一次还原
 *   （默认态 0x0A→PE11(左下) / 0x0B→PE10(右下)；交换态 0x0A→PE10 / 0x0B→PE11；红灯 0x90
 *   不受影响；**不做掉电保存**，`mm_apply_init()` 开机复位为默认态）。
 *   切换时由被调 API 自己打一行 `[mm] TEST: arrow map swapped|restored -> …`（`MM_RTT_DIAG`
 *   门控）——本文件不重复打印。
 *   **不进入**标准版的 SHOW_CODE / 七色满屏 / 通信灯 / 老化循环 / 斜扫序列（那些步骤
 *   全部依赖屏幕判读，缅甸版按用户需求只做映射切换）。
 *
 * ---- TEST 键消费方式（与标准版一致）----
 *   `dev_key_wait_press(DEV_KEY_TST, …)`：TEST 键 EXTI 下降沿在 `dev_key.c` 释放二值信号量，
 *   `wait_press` 获取即**一次性消费**（信号量容量 1、初值 0；`dev_key_sw_init` 创建）。
 *   `app_key` 的 20ms 轮询与信号量互不干扰（轮询只读 GPIO 去抖缓存）。
 *
 * ---- 内存纪律 ----
 *   监控任务全生命周期只创建一次 ⇒ 栈 + TCB 经 `pl_task_static.h` 静态落 CCMRAM
 *   （栈 256 words = 1KB，与标准版同口径；不占 ucHeap）。本文件**不引用任何显示 API**，
 *   因此在「无显示驱动」构建（EIDE `targets.Myanmar` 口径）下同样安全。
 *
 * 详细语义、RTT 日志样例与现场测试矩阵见 `doc/16_缅甸2D费显协议/README.md` §13。
 */

#include "app_factory_test.h"

#include "cmsis_os2.h"
#include "initcall.h"

#include "app_mm_proto.h" /* mm_arrow_map_toggle()（缅甸模块的映射交换 API） */
#include "dev_key.h"      /* dev_key_wait_press(DEV_KEY_TST, …) */
#include "pl_task_guard.h"
#include "pl_task_static.h"

/* ---- 任务静态存储（栈 + TCB 落 CCMRAM，见 pl_task_static.h）----
 * mm_factory_monitor：启动期创建一次、永不退出；栈 256 words 对齐标准版
 * （标准版 factory_monitor 亦为 256；本任务只做 wait_press + 切换 API 调用）。 */
PL_TASK_STATIC_STORAGE(mm_factory_monitor, 256);

/** 监控任务句柄（与标准版同名的对外符号；工程内无外部引用者，保留以对齐契约）。 */
osThreadId_t g_factory_test;

/**
 * @brief  缅甸版监视线程：等 TEST 键 → 切换 0x0A / 0x0B 箭头落点。
 * @param  argument  未使用。
 *
 * `osWaitForever` 阻塞（无业务数据中止语义 —— 本版本没有会被业务数据打断的检测序列；
 * 切换开关本身与业务数据无冲突，收到业务帧时仍可随时按键切换）。
 */
static void mm_factory_monitor_task(void *argument)
{
    (void)argument;

    for (;;) {
        /* 一次性消费 TEST 键（EXTI 信号量）；被唤醒即切换映射，再按一次还原。 */
        if (!dev_key_wait_press(DEV_KEY_TST, osWaitForever))
            continue;
        (void)mm_arrow_map_toggle();
    }
}

/* ---- 模块自注册（与标准版同为 sw_app_initcall，收录序一致 ⇒ initcall 次序不变）---- */
static void _factory_test_init(void)
{
    const osThreadAttr_t attr = {
        .name     = "mm_factory_test",
        .priority = osPriorityHigh,
        PL_TASK_STATIC_ATTR(mm_factory_monitor, 256),
    };
    g_factory_test =
        pl_task_create_checked(osThreadNew(mm_factory_monitor_task, NULL, &attr), "mm_factory_test");
}
sw_app_initcall(_factory_test_init);

/* ==========================================================================
 * 对外契约（与标准版同名同义；语义按「缅甸版无检测序列」如实降级）
 * ========================================================================== */

/**
 * @brief  业务数据到达中止钩子 —— 缅甸版**空实现**。
 *
 * 标准版语义 = 置中止标志让 monitor 回 IDLE（其检测序列占用显示资源，业务数据优先）。
 * 缅甸版没有可被业务数据打断的序列（TEST 键仅切换映射、不占屏），故无中止对象；
 * 保留空函数体纯为「同一套对外符号」契约（`app_dispatch.c` 恒调用它）。
 */
void app_factory_mode_interrupt(void)
{
    /* 无序列可中止：TEST 键切换映射与业务数据互不干扰，不做任何动作。 */
}

/**
 * @brief  工厂测试激活查询（供 CQ 心跳类定时任务判定是否暂停计数）。
 *
 * 缅甸版不进入任何占用显示资源的检测序列 ⇒ **恒 false**（心跳计数照常运行，语义诚实）。
 */
bool app_factory_test_active(void)
{
    return false;
}
