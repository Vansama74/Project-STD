#pragma once

#include <stdint.h>

#include "app_iap.h"
#include "app_dispatch.h"
#include "app_udp.h"

#define FLAG_FORCE_UPDATE      (uint32_t)(0x0000DEADU)
#define FIRMWARE_MAX_FRAME_NUM (768U)
#define FLASH_SECTOR_SIZE      (0x20000U)

#define FIRMWARE_MAXLEN        (FIRMWARE_MAX_FRAME_NUM * 256U)
#define BITMAP_SIZE            (FIRMWARE_MAX_FRAME_NUM / 8)

typedef enum {
    rtn_cmd01 = (uint32_t)0x0000b401U,
    rtn_cmd02 = (uint32_t)0x0000b402U,
    rtn_cmd03 = (uint32_t)0x0000b403U,
    rtn_cmd04 = (uint32_t)0x0000b404U,
    rtn_cmd05 = (uint32_t)0x0000b405U,
    rtn_cmd06 = (uint32_t)0x0000b406U,
    rtn_cmd07 = (uint32_t)0x0000b407U,
} rtn_cmd_t;

typedef void (*iap_cmd_handler_fn_t)(channel_t *, iap_frame_t *);
#define IAP_CMD_COUNT (8U) /* 命令表条目数（cmd 0x00~0x07），与 app_iap_cmd.c 中 g_iap_cmd_table[] 定义保持同步 */
extern const iap_cmd_handler_fn_t g_iap_cmd_table[IAP_CMD_COUNT];
