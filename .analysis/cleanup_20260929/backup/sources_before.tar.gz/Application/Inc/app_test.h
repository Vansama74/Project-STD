/**
 * @file    app_test.h
 * @brief   硬件测试用例 — 显示/渲染/IO 等功能验证
 *
 * 每个测试函数封装一个独立测试场景，可在 init_task 中按需调用。
 * 正式发布时移除 app_test_run() 调用即可。
 */

#pragma once

#include <stdint.h>

#include "dev_display.h"

#define APP_TEST_OBLIQUE_LINE_SPACING (32U)
#define APP_TEST_OBLIQUE_STEP_DELAY_MS (24U)

extern volatile uint32_t g_app_test_oblique_frame_count;

/** @brief 绘制指定相位的一帧斜扫图案 */
void app_test_oblique_scan_frame(dev_display_t *dsp, int16_t phase);

/** @brief 运行全部测试用例 */
void app_test_run(void);

/** @brief 像素扫描测试：逐点亮绿灯再熄灭（持续循环，阻塞） */
void app_test_pixel_scan(void);

/** @brief 渲染测试：显示"通"字验证字库读取正常 */
void app_test_render_text(void);

/** @brief IO 测试：依次点亮车道灯/黄闪灯各 1 秒 */
void app_test_io_output(void);

/** @brief LED 灯序测试：逐通道逐像素点亮 hub75_buff，用于确认物理灯序映射 */
void app_test_led_mapping(void);

/** @brief 扫描行顺序测试：逐行点亮水平线，确认 1/8 扫描的行地址映射 */
void app_test_scan_line_order(void);

/** @brief 对角线测试：验证整体坐标映射是否正确 */
void app_test_diagonal(void);

/** @brief 斜扫测试：显示多条白色斜线连续移动 */
void app_test_oblique_scan(void);

/** @brief prepare 映射测试：通过 set_pixel 逐像素点亮，验证 prepare 像素重排是否正确 */
void app_test_prepare_mapping(void);
